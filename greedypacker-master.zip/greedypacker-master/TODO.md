### To Do:
* Shelf Floor-Ceiling optimization
* global best insert
* improve docs
